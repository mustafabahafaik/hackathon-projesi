# Handoff: Depozito Escrow — web arayüzü (Stellar Pro Hackathon 2026)

## Overview
Depozito Escrow is a rental-deposit escrow product for tenants in Turkey (students in particular).
A landlord opens a lease record and invites the tenant; the tenant deposits the deposit in TRY via a
Stellar anchor (SEP-24); the funds are swapped to USDC (Soroswap) and parked in a DeFindex yield vault
through a Soroban escrow contract. Both parties upload move-in / move-out photographs whose SHA-256
hashes are written on chain. At move-out the undisputed portion is paid immediately, the disputed
portion is frozen, and a time/round-limited offer — counter-offer process runs; if that fails, a
pre-selected arbiter must pick one of the two final numbers (baseball arbitration).

This bundle contains the **front-end design** for that product: a marketing landing page plus the full
signed-in application flow (login → dashboard → deposit → photo evidence → exit settlement → dispute →
arbitration → evidence package), in Turkish, desktop-first.

## About the Design Files
The file in this bundle (`Depozito.dc.html`) is a **design reference created in HTML** — a working
prototype showing intended look and behaviour. It is **not production code to copy**. All data is local
component state and all chain/anchor calls are simulated in the prototype.

The task is to **recreate these designs in the target codebase** — per CLAUDE.md that is
**Next.js (App Router) + TypeScript + TailwindCSS**, Privy for auth/embedded wallet, a Node/TypeScript
API, and real testnet integrations. Every integration must make a real call (no mock/hardcoded data —
that is an explicit hackathon disqualification criterion). UI strings stay Turkish; identifiers,
comments and commit messages stay English.

## Fidelity
**High fidelity.** Colors, typography, spacing, radii, shadows and interaction states all come from the
bound **Nocturne** design system (`styles.css` token sheet, included in this bundle under `_ds/`).
Recreate pixel-faithfully, but map the tokens onto the codebase's own Tailwind theme rather than
re-declaring hexes ad hoc.

## Screens / Views

### 1. Landing (route `/`)
- **Purpose:** explain the product and route the visitor to sign-in or the demo account.
- **Layout:** sticky header (brand left; `Stellar Testnet` tag + `Giriş yap` button right, 1px bottom
  divider) → hero → full-bleed stat band → "Nasıl işliyor" trail → footer.
- **Hero:** `position:relative; overflow:hidden; isolation:isolate`, padding `3.4×space-8` top /
  `1.6×space-8` sides. Decorative layers, all `pointer-events:none`, behind the content:
  1. cursor-follow accent glow — `radial-gradient(560px circle at var(--mx,62%) var(--my,34%),
     color-mix(in srgb, var(--color-accent) 22%, transparent), transparent 66%)`, `transition:background 120ms linear`;
  2. static deep-indigo glow at top right using `--color-section-glow` at 42%, offset by the parallax vars;
  3. 46px grid of `--color-neutral-800` hairlines, revealed only near the cursor via
     `mask-image: radial-gradient(300px circle at var(--mx) var(--my), #000, transparent 72%)`;
  4. two hairlines at 22% top / 16% bottom that fade to transparent at both ends (Nocturne's rule);
  5. two 45°-rotated rounded squares (accent 42% border and `--color-neutral-800` border) translating
     ±14px / ∓22px from the pointer, `transition:transform 260ms ease-out`;
  6. **sakura petals** — 16 spans, 7–15px, `border-radius:100% 8% 100% 8%`, tinted from
     `--color-accent-200/300/400` at 32–72% opacity; outer span animates `sakura-fall` (11–21s linear,
     `translate3d(0,-12vh,0)` → `translate3d(0,86vh,0)`), inner span animates `sakura-sway`
     (3.4–6.2s ease-in-out, `translateX(±26px) rotate(-24deg…26deg)`), negative delays up to −16s so the
     field is pre-populated. Disabled under `prefers-reduced-motion`;
  7. 140px bottom gradient fade into `--color-bg`.
  Content: `.tag.tag-accent` kicker "Kiracı depozitosu emanette"; h1 `clamp(34px,4.4vw,58px)`, weight 500,
  line-height 1.08, letter-spacing −0.03em, max-width 20ch; lead paragraph 16.5px/1.7 `--color-neutral-300`,
  max-width 62ch; buttons `.btn.btn-primary` ("E-posta ile başla") + `.btn.btn-secondary` ("Demo hesabı gör").
- **Stat band:** the one saturated field in the page — `background: var(--color-section)`, padding
  `1.6×space-8`, auto-fit columns min 200px. Four stats (30px heading numbers, 13px `--color-accent-200`
  captions): %4,1 kasa getirisi · 0 gün bekleme · SHA-256 kanıt · 3 tur sonra tahkim.
- **"Nasıl işliyor" trail:** four `.card`s (radius `--radius-lg`, padding `1.2×space-8`) alternating
  left/right in a 2-column grid, each with a 40×40 rounded-square number badge (1px accent 55% border;
  full `--color-accent` on step 04). Between rows: an `<svg viewBox="0 0 400 78" preserveAspectRatio="none">`
  78px tall with a cubic path (`M100 0 C100 46 300 30 300 78`, mirrored on alternate rows),
  `stroke-width:1.4`, `stroke-dasharray:5 7`, round caps, stroked with a horizontal gradient of
  `--color-accent` fading to 0 opacity at both ends.
- **Footer:** 1px top divider, 12.5px `--color-neutral-400`, two lines (project/track, testnet disclaimer).

### 2. Giriş (route `/giris`)
Centered `.card.elev-md`, width `min(430px,100%)`, padding `1.6×space-8`. Two steps:
- **email step** — h1 22px "Hesabınıza giriş yapın", 13.5px explainer, `.field` + `.input` (type email,
  placeholder `ad.soyad@ogrenci.edu.tr`), `.btn.btn-primary.btn-block` "Doğrulama kodu gönder", 12px KVKK note.
  Validation: address must contain "@", else no advance.
- **code step** — 6-digit code field (prototype accepts ≥4 digits), "Doğrula ve gir" primary block button,
  "E-postayı değiştir" ghost button, inline hint line for errors/status.
In production this is Privy e-mail login + embedded wallet; no key material in the UI.

### 3. App shell (route `/uygulama`)
- Header gains: role switch, the signed-in e-mail (12.5px `--color-neutral-300`), "Çıkış" ghost button.
- **Role switch** (Kiracı / Ev sahibi): 1px `--color-neutral-800` container, radius `--radius-md`,
  `space-1` padding; each option 12.5px, `space-2/space-6` padding, radius `--radius-sm`; the **selected**
  option carries an absolutely-positioned overlay — `background: color-mix(in srgb, var(--color-accent) 16%,
  transparent)` + `box-shadow: inset 0 0 0 1px var(--color-accent)`; hover `--color-neutral-900`.
  In production this is the user's real role, not a toggle — keep it only as a demo affordance.
- **Layout:** `grid-template-columns: 290px minmax(0,1fr)`.
- **Sidebar:** "KİRA KAYITLARI" label (11px, 0.08em, uppercase, `--color-neutral-400`) + "+ Yeni" ghost
  button (landlord only); lease cards are buttons with 1px `--color-neutral-800` border, radius
  `--radius-md`, padding `space-4/space-6`, showing address (13.5px), `#id · tutar` (11.5px
  `--color-neutral-300`), status (11px `--color-accent-300`). Selected card: overlay with accent 10% tint
  and a 2px left accent border. Footer note explains the role switch.
- **Main:** max-width 1120px, padding `space-8 / 1.6×space-8`.

### 4. Yeni kira kaydı (landlord)
`.card.elev-md`, 24px h1, auto-fit 240px field grid: Konut adresi, Kiracı e-postası, Depozito (TL),
Kira süresi. Actions: "Kaydı oluştur ve davet gönder" (primary), "Vazgeç" (ghost), inline error text.
Validation: address non-empty, tenant e-mail contains "@", amount parses to a number.
On submit: new lease prepended, selected, `create_lease` event logged.

### 5. Lease detail — tab bar
Six tabs (Özet, Depozito, Fotoğraf kanıtı, Çıkış hesabı, Anlaşmazlık, Delil paketi): borderless buttons,
13.5px, `--color-neutral-300`, padding `space-3` top / `space-4` bottom, hover → `--color-text`;
active tab marked by a 2px `--color-accent` bar pinned to the nav's bottom border (`bottom:-1px`).
Header above: `#id` outline tag, status accent tag, term (12.5px muted), 28px h1 address,
13px "Ev sahibi … · kiracı …" line.

### 6. Özet tab
Four `.card`s (auto-fit 210px, padding `space-8`): emanetteki depozito (27px heading number + TRY line),
biriken getiri (`--color-accent-300`), kanıt (giriş/çıkış hash sayısı), sıradaki adım (18px + who).
Below: "Zincir hareketleri" card containing a `.table` — Zaman / İşlem / Detay / Tx, tx ids as links.

### 7. Depozito tab
`.card.elev-md`; 20px h2 + explainer; read-only amount field and the SEP-38 quote line
(`1 USDC = <rate> TL`, 60s validity); then the four-step list, each row
`grid-template-columns: 24px minmax(0,1fr) auto` with a 1px top divider: mark (✓ / ● / ○ in
`--color-accent-400`), title 14px + sub 12px `--color-neutral-400`, `.tag.tag-neutral` state
(Tamam / Sürüyor / Bekliyor). Steps: KYC (SEP-12) → banka havalesi (SEP-24 interactive) → Soroswap
çevrimi (TRYX→USDC, slippage %0,5) → escrow.deposit() → vault.deposit(). Primary CTA label changes per
step; disabled once complete. Each advance appends a chain event.

### 8. Fotoğraf kanıtı tab
Two cards, "Giriş kanıtı" (locked, count tag) and "Çıkış kanıtı" (accent count tag). Each holds an
auto-fill `minmax(152px,1fr)` grid of 4:3 buttons, radius `--radius-md`, `--color-neutral-900` ground;
filled cells have a solid `--color-neutral-800` border and show `sha256 …` in 10.5px mono; empty cells
have a dashed `--color-neutral-700` border and read "yüklemek için tıkla"; hover border →
`--color-accent-600`. Rooms: Salon, Mutfak, Banyo, Yatak odası, Balkon, Sayaçlar. "Seti kilitle ve
zincire yaz" (primary, disabled when empty or already locked) writes the merkle root; after locking the
set is immutable. Production: presigned S3 upload, hash computed client-side **and** verified server-side.

### 9. Çıkış hesabı tab
- **Split bar:** 22px tall, radius `--radius-md`, three zero-basis flex segments proportional to the
  amounts — itirazsız (`--color-accent-700`), donuk (`--color-neutral-800`), kiracıya
  (`--color-neutral-900`); amounts live in a legend row **below** the bar (9px rounded-square swatch +
  12px label), never inside the segments (label width must not affect proportion).
- **Kesinti talepleri table:** Kalem / Tutar / Kanıt / Kiracı kararı. Tenant sees "Kabul" and "İtiraz"
  ghost buttons on items still `bekliyor`; landlord sees an add-item row (Kalem, Tutar, Kanıt +
  "Kalem ekle" secondary).
- **Actions:** "İtirazsız <tutar> tutarı öde" (primary; disabled when nothing accepted or already settled)
  and, when a disputed item exists, "Tartışmalı kısım için süreci başlat" (secondary) which freezes the
  disputed amount and jumps to the dispute tab.

### 10. Anlaşmazlık tab
Status row: donuk tutar accent tag, round tag (`Tur n/3` or `Karar verildi`), 12.5px note (48h limit).
Two columns `minmax(0,1fr) minmax(0,0.85fr)`:
- **Teklif geçmişi:** entries with a 2px `--color-accent-700` left rule, 13.5px "Taraf · tutar" and 12px
  "Tur n · gerekçe"; empty state text when no offers.
- **Action card**, three mutually exclusive phases: negotiation (offer amount + reason fields,
  "Teklifi gönder" primary, "…teklifini kabul et" secondary when the last offer came from the other side,
  "Son teklif tahkimine geç" ghost), arbitration (two `.card.elev-sm` final-offer cards, 26px numbers,
  one primary "Bu rakamı seç" each — the arbiter cannot type a number), resolved (24px result line,
  explanatory note, "Delil paketini gör" secondary).
Rounds advance every two offers; round > 3 ⇒ arbitration.

### 11. Delil paketi tab
Explainer paragraph, then a card titled `evidence-<leaseId>.json` holding the full event `.table` and
"Paketi indir · JSON" (primary) which really downloads a JSON blob of lease, items, dispute and events.
Production adds the PDF export and `official_ruling` reference.

## Interactions & Behavior
- **Navigation:** landing → login → app (`Demo hesabı gör` jumps straight into the app with
  `mert@ogrenci.edu.tr`); "Çıkış" clears session and returns to landing.
- **Hover:** every interactive surface has a themed hover (`--color-neutral-900` tint, or accent border
  on photo cells); focus is Nocturne's 2px accent `:focus-visible` ring — never a browser default.
- **Animations:** petal fall/sway (see hero); glow `transition:background 120ms linear`; parallax squares
  `transform 260ms ease-out`; no other motion.
- **Pointer tracking:** one passive `pointermove` listener on `window` sets `--mx`/`--my` (px, hero-relative)
  and `--px`/`--py` (−1…1) on the hero element; attach on mount, remove on unmount.
- **Validation:** e-mail contains "@"; code ≥4 digits; new lease needs address + tenant e-mail + amount;
  deduction item needs label + amount; offer needs a numeric amount.
- **Responsive:** desktop-first (design width ~1280). Grids use `auto-fit`/`minmax(0,1fr)` and wrap;
  tables sit in `overflow:auto` wrappers.

## State Management
Prototype state (to be replaced by server data + contract reads):
- `route` (landing | login | app), `lstep` (email | code), `email`, `code`, `codeHint`
- `role` (tenant | landlord) — production: derived from the session, not switchable
- `tab`, `activeId`, `showNew`, form buffers (`nf`, `itLabel/itAmount/itEvidence`, `offerAmount/offerReason`)
- `leases[]`: `{ id, address, landlord, tenant, amount, term, depStep 0–4, phase, photosIn[], photosOut[],
  outLocked, items[{label, amount, evidence, status: kabul|itiraz|bekliyor}], settled,
  dispute { round, offers[{party, amount, reason, round}], ruling {by, amount} } | null, events[] }`
- Derived: undisputed / disputed / tenant-return totals, bar flex ratios, next step, proof counts.

**Contract & storage mapping (CLAUDE.md rule 2 — comment the choice in the Rust source):**
- `instance`: admin, arbiter, DeFindex vault, Soroswap router addresses (global config)
- `persistent`: lease record, photo hashes, offer history, settlement, ruling (must live for months)
- `temporary`: invite token, active offer round session data (worthless once the round closes)
- Functions: `create_lease`, `accept_lease`, `deposit`, `record_photo_hash`, `settle_undisputed`;
  then `initiate_dispute`, `submit_offer`, `submit_final_offer`, `arbitrator_decide`, `official_ruling`.
- Every function needs at least one happy-path test plus one test proving an unauthorized caller is rejected.

## Design Tokens
From `_ds/nocturne-*/styles.css` (`:root`) — use the variables, not literals:
- **Color:** `--color-bg #161826`, `--color-surface #232532`, `--color-text #e9e9ed`,
  `--color-accent #9184d9`, `--color-divider color-mix(in srgb,#e9e9ed 16%,transparent)`;
  accent ramp 100→900: `#f5f4ff #e7e5fe #d2cefd #b5abfc #968ae0 #796cbf #5d5294 #423a6a #2b2741`;
  neutral ramp (dark steps used for surfaces/borders/hover, e.g. `--color-neutral-800/900`);
  section band `--color-section #262a60`, `--color-section-glow #353b80`, `--color-section-ghost #4c5397`.
  Body copy in accent uses `--color-accent-300` (the raw accent is only 3:1 on this ground).
- **Spacing (density 0.70×):** `--space-1 2.8px`, `-2 5.6`, `-3 8.4`, `-4 11.2`, `-6 16.8`, `-8 22.4`.
- **Radius:** `--radius-sm 4px`, `--radius-md 8px`, `--radius-lg 14px`.
- **Shadows:** `--shadow-sm 0 0 0 1px #3f424d`; `--shadow-md` adds `0 6px 18px rgba(0,0,0,.55)`;
  `--shadow-lg` adds `0 16px 40px rgba(0,0,0,.65)`. Never stack shadows.
- **Type:** Inter (`--font-heading` / `--font-body`), headings weight 500 max — hierarchy is size and
  space, not weight. Mono runs (tx ids, hashes, step numbers) use `ui-monospace`.
- **Classes used:** `.btn` (+`.btn-primary` outlined accent, `.btn-secondary`, `.btn-ghost`, `.btn-block`),
  `.tag` (+`.tag-accent`, `.tag-neutral`, `.tag-outline`), `.field`+`.input`, `.card`+`.elev-sm/md`, `.table`.
- **Rule style:** horizontal rules fade to transparent over the last 48px of each end.

## Assets
No bitmaps or icon fonts ship with the design. Decoration is CSS/SVG only (glow, masked grid, rotated
squares, petals, trail paths). Where the product later needs iconography, CLAUDE.md's system calls for
**Phosphor** icons. Photographs, if introduced, go through Nocturne's `.lighten` wrapper and should be
shot on dark grounds.

## Files
- `Depozito.dc.html` — the design: landing + full app flow (this is the file to recreate).
- `Depozito Escrow.dc.html` — earlier annotated screen-by-screen spec (contract call, storage type,
  SEP endpoint, state transition per screen); useful as an implementation checklist.
- `_ds/nocturne-4b90c779-3db0-44d8-937c-11b774600993/styles.css` — the Nocturne token sheet and
  component layer the designs are built on.
- `_ds/nocturne-4b90c779-3db0-44d8-937c-11b774600993/readme.md` — the design system guide.
